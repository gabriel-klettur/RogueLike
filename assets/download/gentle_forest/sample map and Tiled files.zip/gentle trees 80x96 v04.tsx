<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.9" tiledversion="1.9.1" name="gentle trees 80x96 v04" tilewidth="80" tileheight="96" tilecount="2" columns="2">
 <image source="../../19.07a Gentle Forest ($5 palettes)/gentle sheets/gentle trees 80x96 v04.png" width="160" height="96"/>
</tileset>
