<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.9" tiledversion="1.9.1" name="gentle 32x32 v01" tilewidth="32" tileheight="32" tilecount="4" columns="4">
 <image source="../gentle sheets/gentle 32x32 v01.png" width="128" height="32"/>
</tileset>
