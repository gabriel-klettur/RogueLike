<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.9" tiledversion="1.9.1" name="gentle trees 80x96 v02" tilewidth="80" tileheight="96" tilecount="2" columns="2">
 <image source="../gentle sheets/gentle trees 80x96 v02.png" width="160" height="96"/>
</tileset>
