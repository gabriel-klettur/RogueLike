<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.9" tiledversion="1.9.1" name="gentle 32x32 v06" tilewidth="32" tileheight="32" tilecount="4" columns="4">
 <image source="../../19.07a Gentle Forest ($5 palettes)/gentle sheets/gentle 32x32 v06.png" width="128" height="32"/>
</tileset>
